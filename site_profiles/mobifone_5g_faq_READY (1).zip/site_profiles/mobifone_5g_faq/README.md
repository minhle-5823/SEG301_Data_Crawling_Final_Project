# Focused Crawler — MobiFone Customer Support cho Vietnamese Dense Retrieval

Project này được chỉnh riêng cho đề tài **False-Negative-Aware Curriculum Hard Negative Mining for Vietnamese Dense Retrieval**.

## 1. Mục tiêu dữ liệu

Crawler **không cố lấy mọi trang MobiFone**. Nó ưu tiên corpus gần với domain **Customer Support** của CSConDa để dùng làm **candidate document pool** cho:

- BM25 retrieval;
- Dense Retrieval;
- khai thác semi-hard / hard negatives;
- false-negative filtering;
- demo semantic search tiếng Việt.

Dữ liệu crawl **không phải ground truth** và không được dùng thay test set chuẩn của VIRE.

## 2. Seed

Seed chính theo yêu cầu:

```text
https://5g.mobifone.vn/mobifone5g/danh-muc-chinh/cau-hoi-thuong-gap?utm_source=chatgpt.com
```

Crawler normalize thành:

```text
https://5g.mobifone.vn/mobifone5g/danh-muc-chinh/cau-hoi-thuong-gap
```

Để candidate pool Customer Support đa dạng hơn, project có thêm một seed cùng domain:

```text
https://5g.mobifone.vn/ho-tro-khach-hang/cau-hoi-thuong-gap
```

Nếu giảng viên yêu cầu **chỉ đúng 1 seed**, xóa seed thứ hai trong `config.py`; crawler vẫn chạy bình thường.

## 3. Focused Crawl

Crawler chỉ giữ URL trên `5g.mobifone.vn` và ưu tiên các path liên quan:

```text
cau-hoi-thuong-gap
ho-tro-khach-hang
goi-cuoc
dich-vu-di-dong
```

Các khu vực ít phù hợp với Customer Support như tin tức, tuyển dụng, giới thiệu, điều khoản, logo... bị loại khỏi frontier.

Điểm này quan trọng vì nếu crawl toàn website, candidate pool sẽ chứa quá nhiều bài marketing / news, tạo negative không đúng domain và làm hard-negative mining nhiễu hơn.

## 4. Dữ liệu lưu

### Bảng `pages`

```text
url, domain, title, content, depth, status_code, crawled_at,
source_type, relevance_score
```

`source_type` gồm dạng như `faq`, `customer_support`, `package`.

`relevance_score` là điểm heuristic dựa trên các từ khóa Customer Support như thuê bao, gói cước, đăng ký, hủy, dung lượng, SIM, thanh toán, tổng đài...

### Bảng `links`

Lưu quan hệ:

```text
source_url -> target_url
```

### Bảng `documents`

Đây là bảng quan trọng cho Dense Retrieval. Nội dung mỗi trang được chia thành chunk khoảng **180 từ**, overlap **35 từ**:

```text
doc_id
source_url
title
text
source_type
depth
relevance_score
chunk_index
```

Việc chunk giúp một document không quá dài và phù hợp hơn với BM25 / embedding model.

## 5. Output cho đề tài retrieval

Sau crawl sẽ có:

```text
data/crawler.db
data/retrieval_corpus.jsonl
data/retrieval_corpus.csv
```

Trong đó `retrieval_corpus.jsonl` là format tiện nhất để đưa vào pipeline BM25 / Dense Retrieval.

Ví dụ một record:

```json
{
  "doc_id": "mobifone_xxx_000",
  "source_url": "...",
  "title": "...",
  "text": "...",
  "source_type": "faq",
  "depth": 0,
  "relevance_score": 15,
  "chunk_index": 0
}
```

## 6. Liên hệ trực tiếp với đề tài nhóm

Pipeline dự kiến:

```text
VIRE / CSConDa queries + positives
              |
              v
        BM25 / Dense Retriever
              |
              +------ VIRE corpus
              |
              +------ MobiFone crawl corpus
                         |
                         v
                candidate negatives
                         |
               similarity / ranking
                         |
        +----------------+----------------+
        |                                 |
 false-negative filtering          curriculum mining
 loại negative có khả năng         semi-hard -> hard
 thực chất là positive
        |                                 |
        +----------------+----------------+
                         |
                    fine-tuning
                         |
          evaluate ONLY on VIRE test set
              nDCG / MRR / Recall
```

Crawler chỉ **mở rộng candidate document pool**. Không gán các trang crawl thành positive/ground-truth tự động.

## 7. Cấu hình hiện tại

```text
MAX_PAGES = 300
MAX_DEPTH = 3
CHUNK_SIZE_WORDS = 180
CHUNK_OVERLAP_WORDS = 35
```

300 pages là giới hạn trên. Vì đây là focused crawler, số trang thực tế có thể ít hơn nếu frontier Customer Support hết URL phù hợp.

## 8. Cách chạy

Source nằm trực tiếp trong `site_profiles/mobifone_5g_faq/`.
Không thêm folder `mobifone5g_assignment_crawler_MAX300` bên trong.

Từ thư mục gốc repo nhóm:

```bash
python -m pip install -r site_profiles/mobifone_5g_faq/requirements.txt
python site_profiles/mobifone_5g_faq/main.py
```

DB và các file export luôn được lưu trong `site_profiles/mobifone_5g_faq/data/`,
kể cả khi chạy từ thư mục gốc repo. `.gitignore` trong folder này bỏ qua cache,
môi trường ảo và output crawl; `data/.gitkeep` giữ thư mục data trong Git.

Cấu hình hiện tại vẫn là `RESET_DB_ON_START = True`: mỗi lần chạy sẽ xóa DB cũ
rồi crawl lại. Nếu muốn giữ DB cũ, đổi thành `False` trong `config.py`.
Đây không phải cơ chế resume frontier.

Nếu chạy terminal bên trong `site_profiles/mobifone_5g_faq/`:


Windows: double-click

```text
RUN_CRAWLER.bat
```

hoặc:

```bash
python -m pip install -r requirements.txt
python main.py
```

## 9. Tại sao bản này phù hợp hơn bản crawl toàn website?

Bản này tạo corpus có **độ liên quan domain cao hơn**, giảm boilerplate, chấm relevance, phân loại nguồn, và tạo retrieval chunks. Nhờ đó corpus crawl có thể được nối với corpus chuẩn để tìm **hard negatives thực tế**, thay vì chỉ lưu nguyên HTML/text để làm bài crawler đơn thuần.

## 10. Đưa lên branch nhóm

Giải nén ZIP, copy folder `mobifone_5g_faq` vào `site_profiles` của repo nhóm.
Nếu đã có folder cùng tên, đối chiếu trước khi chép đè để giữ các file riêng của nhóm.
Các lệnh sau chạy từ thư mục gốc repo:

```bash
git switch -c phuong-mobifone-crawler
git add site_profiles/mobifone_5g_faq
git diff --cached --stat
git commit -m "Complete MobiFone 5G crawler"
git push -u origin phuong-mobifone-crawler
```

Trưởng nhóm sẽ cập nhật vào main. Chưa có repo nhóm để đối chiếu API profile,
nên bản này là crawler độc lập được sắp xếp đúng folder, chưa xác nhận tích hợp
với crawler chung của nhóm.
