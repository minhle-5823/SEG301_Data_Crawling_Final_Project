from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

TOPIC = "Vietnamese Customer Support Corpus for Dense Retrieval / Hard Negative Mining"

SEED_URLS = [
    "https://5g.mobifone.vn/mobifone5g/danh-muc-chinh/cau-hoi-thuong-gap?utm_source=chatgpt.com",
    # Mở rộng cùng domain Customer Support để candidate pool đa dạng hơn.
    "https://5g.mobifone.vn/ho-tro-khach-hang/cau-hoi-thuong-gap",
]

ALLOWED_DOMAINS = {"5g.mobifone.vn"}

# Ưu tiên đúng domain Customer Support / Telecom.
# URL khớp các từ khóa này sẽ được đưa vào frontier.
INCLUDE_PATH_KEYWORDS = (
    "cau-hoi-thuong-gap",
    "ho-tro-khach-hang",
    "goi-cuoc",
    "dich-vu-di-dong",
    "mobifone5g/danh-muc-chinh/goi-cuoc-5g",
)

# Loại các khu vực ít hữu ích cho dense retrieval Customer Support.
EXCLUDE_PATH_KEYWORDS = (
    "tin-tuc",
    "su-kien",
    "tuyen-dung",
    "gioi-thieu",
    "hop-tac",
    "logo",
    "chinh-sach",
    "dieu-khoan",
    "bao-mat",
    "sitemap",
)

# Từ khóa nội dung để chấm relevance cho corpus.
CUSTOMER_SUPPORT_KEYWORDS = (
    "câu hỏi", "trả lời", "khách hàng", "thuê bao", "gói cước", "đăng ký",
    "hủy", "kiểm tra", "dung lượng", "data", "5g", "4g", "sim", "esim",
    "dịch vụ", "thanh toán", "nạp tiền", "cước", "tổng đài", "hỗ trợ",
    "kết nối", "mạng", "điện thoại", "roaming", "chuyển vùng",
)

MAX_DEPTH = 3
MAX_PAGES = 300
REQUEST_TIMEOUT = 12
CRAWL_DELAY = 1.2

USER_AGENT = (
    "VIRE-CustomerSupport-ResearchCrawler/1.0 "
    "(educational research; polite focused crawler)"
)

DATABASE_PATH = str(BASE_DIR / "data" / "crawler.db")
RESET_DB_ON_START = True

# Retrieval corpus exports for BM25 / Dense Retrieval / hard-negative mining.
EXPORT_JSONL_PATH = str(BASE_DIR / "data" / "retrieval_corpus.jsonl")
EXPORT_CSV_PATH = str(BASE_DIR / "data" / "retrieval_corpus.csv")
MIN_CONTENT_CHARS = 120
CHUNK_SIZE_WORDS = 180
CHUNK_OVERLAP_WORDS = 35
MIN_RELEVANCE_SCORE = 1

IGNORED_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".svg", ".css", ".js",
    ".zip", ".rar", ".7z", ".pdf", ".mp3", ".mp4", ".avi",
    ".mov", ".webm", ".ico", ".woff", ".woff2", ".ttf",
}
