import re
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

from bs4 import BeautifulSoup

from config import (
    ALLOWED_DOMAINS,
    CUSTOMER_SUPPORT_KEYWORDS,
    EXCLUDE_PATH_KEYWORDS,
    IGNORED_EXTENSIONS,
    INCLUDE_PATH_KEYWORDS,
)

TRACKING_QUERY_PREFIXES = (
    "utm_", "fbclid", "gclid", "mc_cid", "mc_eid", "_rsc",
)


def normalize_url(url: str) -> str:
    parsed = urlparse(url.strip())
    scheme = parsed.scheme.lower()
    host = parsed.netloc.lower()
    path = parsed.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")

    query_items = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        key_lower = key.lower()
        if key_lower.startswith("utm_") or key_lower in TRACKING_QUERY_PREFIXES:
            continue
        query_items.append((key, value))

    query = urlencode(sorted(query_items))
    return urlunparse((scheme, host, path, parsed.params, query, ""))


def is_allowed_domain(netloc: str) -> bool:
    host = netloc.lower().split(":")[0]
    return host in ALLOWED_DOMAINS


def has_ignored_extension(url: str) -> bool:
    path = urlparse(url).path.lower()
    return any(path.endswith(ext) for ext in IGNORED_EXTENSIONS)


def should_ignore_raw_href(href: str) -> bool:
    if not href:
        return True
    href_lower = href.strip().lower()
    return (
        href_lower.startswith("mailto:")
        or href_lower.startswith("javascript:")
        or href_lower.startswith("tel:")
        or href_lower.startswith("data:")
        or href_lower.startswith("#")
    )


def is_relevant_url(url: str) -> bool:
    """Focused filter: keep URLs likely to contain customer-support documents."""
    parsed = urlparse(url)
    path_query = f"{parsed.path}?{parsed.query}".lower()

    if any(k in path_query for k in EXCLUDE_PATH_KEYWORDS):
        return False

    return any(k in path_query for k in INCLUDE_PATH_KEYWORDS)


def extract_links(soup: BeautifulSoup, current_url: str):
    links = []
    for tag in soup.find_all("a", href=True):
        href = tag.get("href", "").strip()
        if should_ignore_raw_href(href):
            continue

        absolute = normalize_url(urljoin(current_url, href))
        parsed = urlparse(absolute)
        if parsed.scheme not in {"http", "https"}:
            continue
        if not is_allowed_domain(parsed.netloc):
            continue
        if has_ignored_extension(absolute):
            continue
        if not is_relevant_url(absolute):
            continue
        links.append(absolute)

    return list(dict.fromkeys(links))


def _clean_soup(soup: BeautifulSoup) -> BeautifulSoup:
    # Remove obvious boilerplate / non-visible content.
    for tag in soup(["script", "style", "noscript", "template", "svg", "canvas"]):
        tag.decompose()

    # Common page chrome that tends to hurt retrieval quality.
    for selector in [
        "header", "footer", "nav", ".breadcrumb", ".breadcrumbs",
        ".social", ".share", ".cookie", ".popup", ".modal",
    ]:
        for tag in soup.select(selector):
            tag.decompose()
    return soup


def relevance_score(title: str, content: str, url: str) -> int:
    text = f"{title} {content} {url}".lower()
    score = sum(1 for kw in CUSTOMER_SUPPORT_KEYWORDS if kw in text)

    # Strong bonus for FAQ/support pages, which are closest to CSConDa domain.
    if "cau-hoi-thuong-gap" in url.lower():
        score += 5
    if "ho-tro-khach-hang" in url.lower():
        score += 3
    if "goi-cuoc" in url.lower():
        score += 2
    return score


def detect_source_type(url: str, title: str) -> str:
    s = f"{url} {title}".lower()
    if "cau-hoi-thuong-gap" in s:
        return "faq"
    if "goi-cuoc" in s:
        return "package"
    if "ho-tro-khach-hang" in s:
        return "customer_support"
    return "support_document"


def extract_page_info(soup: BeautifulSoup, url: str, depth: int, status_code: int):
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    soup = _clean_soup(soup)

    # Prefer main/article when present; fallback to body.
    root = soup.select_one("main") or soup.select_one("article") or soup.body or soup
    content = root.get_text(" ", strip=True)
    content = re.sub(r"\s+", " ", content).strip()

    return {
        "url": url,
        "domain": urlparse(url).netloc,
        "title": title,
        "content": content,
        "depth": depth,
        "status_code": status_code,
        "source_type": detect_source_type(url, title),
        "relevance_score": relevance_score(title, content, url),
    }
