import csv
import json
import sqlite3
from pathlib import Path

from config import (
    CHUNK_OVERLAP_WORDS,
    CHUNK_SIZE_WORDS,
    EXPORT_CSV_PATH,
    EXPORT_JSONL_PATH,
    MIN_CONTENT_CHARS,
    MIN_RELEVANCE_SCORE,
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT UNIQUE,
    domain TEXT,
    title TEXT,
    content TEXT,
    depth INTEGER,
    status_code INTEGER,
    crawled_at TEXT,
    source_type TEXT,
    relevance_score INTEGER
);

CREATE TABLE IF NOT EXISTS links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_url TEXT,
    target_url TEXT,
    UNIQUE(source_url, target_url)
);

CREATE TABLE IF NOT EXISTS documents (
    doc_id TEXT PRIMARY KEY,
    source_url TEXT,
    title TEXT,
    text TEXT,
    source_type TEXT,
    depth INTEGER,
    relevance_score INTEGER,
    chunk_index INTEGER
);

CREATE INDEX IF NOT EXISTS idx_pages_domain ON pages(domain);
CREATE INDEX IF NOT EXISTS idx_pages_depth ON pages(depth);
CREATE INDEX IF NOT EXISTS idx_pages_relevance ON pages(relevance_score);
CREATE INDEX IF NOT EXISTS idx_links_source ON links(source_url);
CREATE INDEX IF NOT EXISTS idx_links_target ON links(target_url);
CREATE INDEX IF NOT EXISTS idx_docs_source ON documents(source_url);
"""


def chunk_text(text: str, size: int = CHUNK_SIZE_WORDS, overlap: int = CHUNK_OVERLAP_WORDS):
    words = text.split()
    if not words:
        return []
    if len(words) <= size:
        return [text]

    chunks = []
    step = max(1, size - overlap)
    for start in range(0, len(words), step):
        chunk = words[start:start + size]
        if len(chunk) < 40 and chunks:
            break
        chunks.append(" ".join(chunk))
        if start + size >= len(words):
            break
    return chunks


class CrawlerDB:
    def __init__(self, path: str):
        db_path = Path(path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def save_page(self, page: dict):
        self.conn.execute(
            """
            INSERT OR REPLACE INTO pages
            (url, domain, title, content, depth, status_code, crawled_at,
             source_type, relevance_score)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                page["url"], page["domain"], page["title"], page["content"],
                page["depth"], page["status_code"], page["crawled_at"],
                page["source_type"], page["relevance_score"],
            ),
        )

    def save_documents(self, page: dict):
        content = page["content"].strip()
        if len(content) < MIN_CONTENT_CHARS:
            return 0
        if page["relevance_score"] < MIN_RELEVANCE_SCORE:
            return 0

        count = 0
        for i, text in enumerate(chunk_text(content)):
            doc_id = f"mobifone_{abs(hash(page['url']))}_{i:03d}"
            self.conn.execute(
                """
                INSERT OR REPLACE INTO documents
                (doc_id, source_url, title, text, source_type, depth,
                 relevance_score, chunk_index)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    doc_id, page["url"], page["title"], text,
                    page["source_type"], page["depth"],
                    page["relevance_score"], i,
                ),
            )
            count += 1
        return count

    def save_link(self, source_url: str, target_url: str):
        self.conn.execute(
            "INSERT OR IGNORE INTO links(source_url, target_url) VALUES (?, ?)",
            (source_url, target_url),
        )

    def export_retrieval_corpus(self):
        rows = self.conn.execute(
            """
            SELECT doc_id, source_url, title, text, source_type, depth,
                   relevance_score, chunk_index
            FROM documents
            ORDER BY relevance_score DESC, source_url, chunk_index
            """
        ).fetchall()
        columns = [
            "doc_id", "source_url", "title", "text", "source_type",
            "depth", "relevance_score", "chunk_index",
        ]

        for out in [EXPORT_JSONL_PATH, EXPORT_CSV_PATH]:
            Path(out).parent.mkdir(parents=True, exist_ok=True)

        with open(EXPORT_JSONL_PATH, "w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(dict(zip(columns, row)), ensure_ascii=False) + "\n")

        with open(EXPORT_CSV_PATH, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(columns)
            writer.writerows(rows)
        return len(rows)

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.commit()
        self.conn.close()
